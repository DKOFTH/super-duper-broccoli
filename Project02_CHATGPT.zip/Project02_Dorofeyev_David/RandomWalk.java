import java.awt.Point;
import java.util.ArrayList;
import java.util.Random;

import edu.cwi.randomwalk.RandomWalkInterface;

public class RandomWalk implements RandomWalkInterface {

    private int gridSize;
    private boolean flagDone;
    private Point start;
    private Point end;
    private Point currentPoint;
    private Random gen;
    private ArrayList<Point> path;
    
    public RandomWalk(int gridSize) {
        this(gridSize, 0);
    }
    public RandomWalk(int gridSize, long seed) {
        gen = new Random(seed); 
        flagDone = false;
        start = new Point(0, gridSize - 1);
        end = new Point(gridSize - 1, 0);
        currentPoint = start;
        this.gridSize = gridSize;
        path = new ArrayList<Point>();
        path.add(currentPoint);

    }
 
    @Override
    public void step() {
        if ((currentPoint.x == end.x) && currentPoint.y == end.y) {
            flagDone = true;
        } else {
            if (currentPoint.x == end.x) {
                currentPoint.x = gridSize - 1;
                currentPoint.y -= 1;
                path.add(currentPoint);
            } else if (currentPoint.y == end.y) {
                currentPoint.x += 1;
                currentPoint.y = 0;
                path.add(currentPoint);
            } else if (gen.nextBoolean()) {
                currentPoint.y -= 1;
                path.add(currentPoint);
            } else {
                currentPoint.x += 1;
                path.add(currentPoint);
            }            
        }
        
    }  

    @Override
    public void createWalk() {
        while (!flagDone) {
            step();
        }
        
    }

    @Override
    public boolean isDone() {
        return flagDone;
    }

    @Override
    public int getGridSize() {
        return gridSize;
    }

    @Override
    public Point getStartPoint() {
        return start;
    }

    @Override
    public Point getEndPoint() {
        return end;
    }

    @Override
    public Point getCurrentPoint() {
        return currentPoint;
    }

    @Override
    public ArrayList<Point> getPath() {
        return path;
    }

    @Override
    public String toString() {
        String listing = "";
        for (Point currentPoint : path) {
            listing += (listing = " [" + currentPoint.x + "," + currentPoint.y + "]");
        }
        return listing;
    }

}  
// if ((currentPoint.x == gridSize - 1) && currentPoint.y == 0) {
//     flagDone = true;
// } else {
//     if (currentPoint.x == gridSize - 1) {
//         currentPoint = new Point(gridSize - 1, currentPoint.y - 1);
//         path.add(currentPoint);
//     } else if (currentPoint.y == 0) {
//         currentPoint = new Point(currentPoint.x + 1, 0);
//         path.add(currentPoint);
//     } else if (gen.nextBoolean()) {
//         currentPoint = new Point(currentPoint.x, currentPoint.y - 1);
//         path.add(currentPoint);
//     } else {
//         currentPoint = new Point(currentPoint.x + 1, currentPoint.y);
//         path.add(currentPoint);
//     }            
// }
