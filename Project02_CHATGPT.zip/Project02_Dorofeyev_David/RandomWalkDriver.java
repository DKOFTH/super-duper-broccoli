import java.util.Scanner;

public class RandomWalkDriver {
    public static void main(String[] args) {
        int gridSize, seed;
        Scanner scan;
        RandomWalk randomWalk;
        
        scan = new Scanner(System.in);

        do {
            System.out.println("Enter the grid size: ");
            gridSize = scan.nextInt();
            if (gridSize < 0) {
                System.out.println("Error: grid size must be positive!");
            } else {
                do {
                    System.out.println("Enter random seed (0 for no seed): ");
                    seed = scan.nextInt();
                    if (seed < 0) {
                        System.out.println("Error: random seeed must be >= 0");
                    } else if (seed == 0) {
                        randomWalk = new RandomWalk(gridSize);
                        randomWalk.createWalk();
                        System.out.println(randomWalk);
                    } else {
                        randomWalk = new RandomWalk(gridSize, seed);  
                        randomWalk.createWalk();
                        System.out.println(randomWalk);
                    }
                } while (seed < 0);
            }
        } while (gridSize < 0);
        scan.close();
    }
}
